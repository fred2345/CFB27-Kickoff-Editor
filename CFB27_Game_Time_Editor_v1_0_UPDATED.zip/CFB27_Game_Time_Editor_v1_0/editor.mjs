import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { inflateSync } from 'node:zlib';
import Franchise from 'madden-franchise';

const savePath=process.argv[2];
if(!savePath||!fs.existsSync(savePath)){console.error('No Dynasty save was supplied.');process.exit(1);}
function val(r,k){try{return r.getValueByKey(k)}catch{} try{return r[k]}catch{} return null}
function ref(r,k){try{return r.getReferenceDataByKey(k)}catch{return null}}
function fmtTime(v){const n=Number(v);if(!Number.isFinite(n)||n>=2047)return 'Unknown';const mins=((Math.round(n)%1440)+1440)%1440;let h=Math.floor(mins/60),m=mins%60;const ap=h>=12?'PM':'AM';let hh=h%12;if(!hh)hh=12;return `${hh}:${String(m).padStart(2,'0')} ${ap}`}
function parseTime(s){const m=String(s).trim().match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i);if(!m)return null;let h=+m[1],min=+(m[2]??0),ap=m[3]?.toLowerCase();if(min>59)return null;if(ap){if(h<1||h>12)return null;if(ap==='pm'&&h!==12)h+=12;if(ap==='am'&&h===12)h=0}else if(h>23)return null;return h*60+min}
function ask(rl,q){return new Promise(r=>rl.question(q,a=>r(a.trim())))}
function teamName(r){for(const k of ['Name','TeamName','DisplayName','ShortName','Nickname','NickName','SchoolName','FullName','CityName']){const v=val(r,k);if(typeof v==='string'&&v.trim())return v.trim()}return null}
function compressDatabase(buf){const base=path.join(os.tmpdir(),`cfb27-frtk-${process.pid}-${Date.now()}`),inp=base+'.bin',out=base+'.z',helper=path.join(path.dirname(fileURLToPath(import.meta.url)),'libdeflate-compress.py');try{fs.writeFileSync(inp,buf);let py='python';try{execFileSync(py,['-c','import deflate'],{stdio:'ignore'})}catch{py='py';execFileSync(py,['-3','-c','import deflate'],{stdio:'ignore'})}const args=py==='py'?['-3',helper,inp,out]:[helper,inp,out];execFileSync(py,args,{stdio:'pipe'});return fs.readFileSync(out)}finally{for(const f of [inp,out])try{fs.unlinkSync(f)}catch{}}}
function diffBytes(a,b){const out=[];const n=Math.max(a.length,b.length);for(let i=0;i<n;i++)if(a[i]!==b[i])out.push(i);return out}
function groupRanges(offsets){if(!offsets.length)return[];const out=[];let s=offsets[0],p=s;for(let i=1;i<offsets.length;i++){const x=offsets[i];if(x===p+1){p=x}else{out.push([s,p]);s=p=x}}out.push([s,p]);return out}

console.log('\n==============================================');console.log('       CFB 27 GAME TIME EDITOR v1.0');console.log('        MINIMAL-DIFF SAFE WRITER');console.log('==============================================\n');
console.log('Loading:',path.resolve(savePath));console.log('Parsing Dynasty save...');
let file;try{file=await Franchise.create(savePath,{autoParse:true,gameYearOverride:27,gameTypeOverride:'college'})}catch(e){console.error('Failed to parse CFB27 Dynasty:',e?.message||e);process.exit(2)}
const candidates=file.tables.filter(t=>t?.name==='SeasonGame');let table=candidates.find(t=>Number(t?.header?.tableId)===6347);if(!table)table=candidates.slice().sort((a,b)=>Number(b?.header?.nextRecordToUse??0)-Number(a?.header?.nextRecordToUse??0))[0];if(!table){console.error('Could not find SeasonGame table.');process.exit(3)}
let teamTable=null;try{teamTable=file.tables.find(t=>Number(t?.header?.uniqueId)===3359508968)}catch{}if(!teamTable){try{teamTable=file.tables.find(t=>Number(t?.header?.tableId)===6351)}catch{}}if(!teamTable){console.error('Could not locate main Team table.');process.exit(4)}
await teamTable.readRecords(['Name','TeamName','DisplayName','ShortName','Nickname','NickName','SchoolName','FullName','CityName']);const names=new Map();for(const r of teamTable.records||[]){if(!r||r.isEmpty)continue;const n=teamName(r);if(n)names.set(r.index,n)}
function nameFromRef(x){return x?names.get(Number(x.rowNumber))||`Team ${x.rowNumber}`:'Unknown Team'}
const fields=['SeasonYear','SeasonWeek','SeasonWeekType','SeasonGameNum','GameDateMonth','GameDateDay','DayOfWeek','TimeOfDay','BroadcastNetwork','IsGameOfTheWeek','IsKickoffGame','AwayTeam','HomeTeam','HomeScore','AwayScore','GameStatus'];await table.readRecords(fields);
const games=(table.records||[]).filter(r=>r&&!r.isEmpty).map(r=>({row:r.index,week:Number(val(r,'SeasonWeek')),month:Number(val(r,'GameDateMonth')),day:Number(val(r,'GameDateDay')),dow:val(r,'DayOfWeek'),time:Number(val(r,'TimeOfDay')),awayRef:ref(r,'AwayTeam'),homeRef:ref(r,'HomeTeam'),record:r}));
console.log(`Using SeasonGame tableId=${table.header?.tableId}; populated records=${games.length}`);console.log(`Loaded ${names.size} team names.\n`);
const rl=readline.createInterface({input:process.stdin,output:process.stdout});const weeks=[...new Set(games.map(g=>g.week))].sort((a,b)=>a-b);console.log('Available weeks:',weeks.join(', '));const week=Number(await ask(rl,'\nEnter week number: '));if(!weeks.includes(week)){console.log('Invalid week.');rl.close();process.exit(5)}const list=games.filter(g=>g.week===week);console.log(`\nGames in Week ${week}:`);for(let i=0;i<list.length;i++){const g=list[i];g.away=nameFromRef(g.awayRef);g.home=nameFromRef(g.homeRef);console.log(`${String(i+1).padStart(2,' ')}. ${g.away} @ ${g.home} | ${g.month}/${g.day} ${g.dow} | ${fmtTime(g.time)} | row ${g.row}`)}
const pick=Number(await ask(rl,'\nSelect game number (0 to cancel): '));if(!pick){rl.close();process.exit(0)}if(pick<1||pick>list.length){console.log('Invalid game selection.');rl.close();process.exit(6)}const game=list[pick-1];console.log(`\nSelected: ${game.away} @ ${game.home}`);console.log(`Current kickoff: ${fmtTime(game.time)}`);const newTime=parseTime(await ask(rl,'New kickoff: '));if(newTime===null){console.log('Invalid time.');rl.close();process.exit(7)}const originalTime=Number(val(game.record,'TimeOfDay'));game.record.TimeOfDay=newTime;console.log(`✓ In-memory TimeOfDay changed: ${originalTime} -> ${newTime}`);

// CRITICAL DIFFERENCE FROM v0.8: do not write the entire regenerated FrTk buffer.
// Generate it only to discover the exact byte/bit delta caused by TimeOfDay, then
// apply those deltas to the ORIGINAL decompressed database. This preserves every
// other byte of EA's original database.
let generated;try{generated=file.strategy.file.generateUnpackedContents(file.tables,file.unpackedFileContents)}catch(e){console.error('Could not generate comparison buffer:',e?.message||e);rl.close();process.exit(8)}
const originalPacked=file.packedFileContents;const originalSize=originalPacked.readUInt32LE(0x4a);const originalCompressed=originalPacked.subarray(0x52,0x52+originalSize);let originalDb;try{originalDb=inflateSync(originalCompressed)}catch(e){console.error('Could not decompress original FrTk database:',e?.message||e);rl.close();process.exit(9)}
if(originalDb.length!==generated.length){console.error(`DATABASE SIZE MISMATCH: original=${originalDb.length}, generated=${generated.length}`);rl.close();process.exit(10)}
const diffs=diffBytes(originalDb,generated);const ranges=groupRanges(diffs);console.log(`\nMinimal-diff analysis: ${diffs.length} changed byte(s) across ${ranges.length} range(s).`);console.log('Ranges:',ranges.slice(0,20).map(([a,b])=>`${a}-${b}`).join(', ')+(ranges.length>20?' ...':''));
if(diffs.length===0){console.error('No database bytes changed.');rl.close();process.exit(11)}
if(diffs.length>64||ranges.length>16){console.error('SAFE ABORT: the library changed too many database bytes for a one-field kickoff edit.');console.error('This version will NOT write the save.');rl.close();process.exit(12)}
const patched=Buffer.from(originalDb);for(const i of diffs)patched[i]=generated[i];
// Prove the candidate differs from EA's original DB only at the exact deltas.
const verifyDiff=diffBytes(originalDb,patched);if(verifyDiff.length!==diffs.length||verifyDiff.some((x,i)=>x!==diffs[i])){console.error('Internal minimal-diff verification failed.');rl.close();process.exit(13)}
const compressed=compressDatabase(patched);const streamEnd=0x52+originalSize;const tail=originalPacked.subarray(streamEnd);let slack=tail.findIndex(b=>b!==0);if(slack===-1)slack=tail.length;const budget=originalSize+slack;if(compressed.length>budget){console.error(`Compressed database exceeds safe slot: ${compressed.length} > ${budget}`);rl.close();process.exit(14)}
const header=Buffer.from(originalPacked.subarray(0,0x52));header.writeUInt32LE(compressed.length,0x4a);const padding=Buffer.alloc(budget-compressed.length);const output=Buffer.concat([header,compressed,padding,originalPacked.subarray(0x52+budget)]);if(output.length!==originalPacked.length){console.error('Output size changed unexpectedly.');rl.close();process.exit(15)}
const temp=`${savePath}.CFB27EDIT.tmp`;fs.writeFileSync(temp,output);console.log(`✓ Wrote minimal-diff temporary save (${diffs.length} DB bytes changed).`);
console.log('\nValidating temporary output...');let check;try{check=await Franchise.create(temp,{autoParse:true,gameYearOverride:27,gameTypeOverride:'college'})}catch(e){console.error('VALIDATION FAILED: could not reopen temporary save:',e?.message||e);rl.close();process.exit(16)}let vt=check.tables.filter(t=>t?.name==='SeasonGame').find(t=>Number(t?.header?.tableId)===6347);if(!vt){console.error('VALIDATION FAILED: SeasonGame 6347 missing.');rl.close();process.exit(17)}await vt.readRecords(['TimeOfDay','AwayTeam','HomeTeam']);const vr=(vt.records||[]).find(r=>r&&!r.isEmpty&&Number(r.index)===Number(game.row));const got=vr?Number(val(vr,'TimeOfDay')):NaN;if(got!==newTime){console.error(`VALIDATION FAILED: row ${game.row} has ${got}, expected ${newTime}.`);rl.close();process.exit(18)}console.log(`✓ Reopened row ${game.row}: TimeOfDay=${got} (${fmtTime(got)})`);
fs.copyFileSync(temp,savePath);fs.unlinkSync(temp);console.log('\n==============================================');console.log('             VALIDATION PASSED');console.log('==============================================');console.log(`✓ Backup overwritten: ${savePath}`);console.log(`✓ ${game.away} @ ${game.home}: ${fmtTime(originalTime)} -> ${fmtTime(newTime)}`);console.log('✓ Minimal-diff writer used: all non-TimeOfDay database bytes preserved.');console.log('\nNow test this exact backup in CFB 27.');rl.close();
