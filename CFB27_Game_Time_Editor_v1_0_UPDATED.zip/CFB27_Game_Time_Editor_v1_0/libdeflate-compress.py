import sys, zlib, deflate
inp, outp = sys.argv[1], sys.argv[2]
data=open(inp,'rb').read()
compressed=deflate.zlib_compress(data,12)
if zlib.decompress(compressed)!=data:
    raise SystemExit('libdeflate round-trip verification failed')
open(outp,'wb').write(compressed)
