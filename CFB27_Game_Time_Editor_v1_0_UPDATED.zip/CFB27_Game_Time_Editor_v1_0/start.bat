@echo off
setlocal
cd /d "%~dp0"
set "SAVE="
for /f "delims=" %%I in ('powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $f=New-Object Windows.Forms.OpenFileDialog; $f.Title='Select your CFB 27 Dynasty backup'; $f.Filter='All files (*.*)|*.*'; $f.Multiselect=$false; if($f.ShowDialog() -eq 'OK'){[Console]::Write($f.FileName)}"') do set "SAVE=%%I"
if not defined SAVE (echo No save selected.&pause&exit /b 1)
where node >nul 2>nul || (echo Node.js is required.&pause&exit /b 1)
where npm >nul 2>nul || (echo npm is required.&pause&exit /b 1)
python -c "import deflate" >nul 2>nul
if errorlevel 1 (
  py -3 -c "import deflate" >nul 2>nul
  if errorlevel 1 (
    echo Installing required Python package: deflate
    py -3 -m pip install deflate
    if errorlevel 1 (echo Failed to install deflate.&pause&exit /b 1)
  )
)
if not exist node_modules\madden-franchise (
  echo Installing madden-franchise...
  call npm install
  if errorlevel 1 (echo npm install failed.&pause&exit /b 1)
)
node editor.mjs "%SAVE%"
echo.
pause
